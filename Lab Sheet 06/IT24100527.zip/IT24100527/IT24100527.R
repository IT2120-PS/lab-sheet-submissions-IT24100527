#1
setwd("C:\\Users\\it24100527\\Desktop\\IT24100527\\Lab06")
#i
#Binomial Distribution

#ii
1 - pbinom(46, 50, 0.85, lower.tail = TRUE)
pbinom(46, 50, 0.85, lower.tail = FALSE)

#2
#i
# Number of customer calls received per hour

#ii
# Poisson distribution

#iii
dpois(15, 12)
